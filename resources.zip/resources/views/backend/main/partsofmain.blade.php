
					<!--begin:::Col-->
					<div class="col-xl-6">
						<!--begin::Chart Widget 1-->
						<div class="card card-xl-stretch mb-5 mb-xl-8">
							<!--begin::Body-->
							<div class="card-body p-0 d-flex justify-content-between flex-column">
								<div class="d-flex flex-stack card-p flex-grow-1">
									<!--begin::Icon-->
									<div class="symbol symbol-45px symbol-circle">
										<div class="symbol-label">
											<!--begin::Svg Icon | path: icons/duotone/Shopping/Cart4.svg-->
											<span class="svg-icon svg-icon-2x">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<path opacity="0.25" d="M3.19406 11.1644C3.09247 10.5549 3.56251 10 4.18045 10H19.8195C20.4375 10 20.9075 10.5549 20.8059 11.1644L19.4178 19.4932C19.1767 20.9398 17.9251 22 16.4586 22H7.54138C6.07486 22 4.82329 20.9398 4.58219 19.4932L3.19406 11.1644Z" fill="#7E8299" />
													<path d="M2 9.5C2 8.67157 2.67157 8 3.5 8H20.5C21.3284 8 22 8.67157 22 9.5C22 10.3284 21.3284 11 20.5 11H3.5C2.67157 11 2 10.3284 2 9.5Z" fill="#7E8299" />
													<path d="M10 13C9.44772 13 9 13.4477 9 14V18C9 18.5523 9.44772 19 10 19C10.5523 19 11 18.5523 11 18V14C11 13.4477 10.5523 13 10 13Z" fill="#7E8299" />
													<path d="M14 13C13.4477 13 13 13.4477 13 14V18C13 18.5523 13.4477 19 14 19C14.5523 19 15 18.5523 15 18V14C15 13.4477 14.5523 13 14 13Z" fill="#7E8299" />
													<g opacity="0.25">
														<path d="M10.7071 3.70711C11.0976 3.31658 11.0976 2.68342 10.7071 2.29289C10.3166 1.90237 9.68342 1.90237 9.29289 2.29289L4.29289 7.29289C3.90237 7.68342 3.90237 8.31658 4.29289 8.70711C4.68342 9.09763 5.31658 9.09763 5.70711 8.70711L10.7071 3.70711Z" fill="#7E8299" />
														<path d="M13.2929 3.70711C12.9024 3.31658 12.9024 2.68342 13.2929 2.29289C13.6834 1.90237 14.3166 1.90237 14.7071 2.29289L19.7071 7.29289C20.0976 7.68342 20.0976 8.31658 19.7071 8.70711C19.3166 9.09763 18.6834 9.09763 18.2929 8.70711L13.2929 3.70711Z" fill="#7E8299" />
													</g>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</div>
									</div>
									<!--end::Icon-->
									<!--begin::Text-->
									<div class="d-flex flex-column text-end">
										<a href="#" class="fw-boldest text-gray-800 text-hover-primary fs-2">Orders</a>
										<span class="text-gray-400 fw-bold fs-6">Sep 1 - Sep 16 2020</span>
									</div>
									<!--end::Text-->
								</div>
								<!--begin::Chart-->
								<div class="pt-1">
									<div id="kt_chart_widget_1_chart" class="card-rounded-bottom h-125px">
									</div>
								</div>
								<!--end::Chart-->
							</div>
						</div>
						<!--end::Chart Widget 1-->
					</div>
					<!--end:::Col-->