<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\Brand;
use App\Models\ProductMedia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use phpDocumentor\Reflection\Types\Null_;

class CategoryController extends Controller
{

    //for category page
    public function index(Request $request, $slug)
    {
        $main_category = Category::where('slug', $slug)->with('parent.parent')->first();
        $parent_id = $this->findParent($main_category->id);
        $sub_categories = Category::where('parent_id', $parent_id)->with('subcategory')->get();
        $categories = Category::where('parent_id', $main_category->id)->get();
        $brands = Brand::select('id', 'name')->where(['status' => 1, 'flag' =>  0])->get();

        $product_category = array();
        $min_price_filter = 0;
        $max_price_filter = DB::table('products')->max('sale_price') + 100;
        $min_price_old = 0;
        $max_price_old = 0;
        if (!empty($request->min_price_filter)) {
            $min_price_old = floatval($request->min_price_filter);
        }
        if (!empty($request->max_price_filter)) {
            $max_price_old = floatval($request->max_price_filter);
        }

        //fiter function begin
        $filter_old = array();
        $filter_old_price = array();
        $filter_sorting = "";
        $filter_brands = array();

        //brands filter begin 
        if (!empty($request->filter_brand) && count($request->filter_brand) > 0) {
            $filter_brands = array_merge($filter_brands, $request->filter_brand);
        }
        //brands filter end

        if (empty($request->filter_category)) {
            array_push($filter_old, $main_category->slug);
            array_push($product_category, $main_category->id);
        }

        if (!empty($request->filter_category) && count($request->filter_category) > 0) {
            if (in_array($main_category->slug, $request->filter_category)) {
                array_push($filter_old, $main_category->slug);
                array_push($product_category, $main_category->id);
            }

            $check_categories = Category::select('id')->whereIn('slug', $request->filter_category)->get()->toArray();
            $check_categories = array_column($check_categories, 'id');
            $request->check_categories = $check_categories;
            $filter_old = $request->filter_category;
        }

        //filter function end
        if (!empty($request->filter_category) && count($request->filter_category) > 0) {
            $product_category = array_merge($product_category, $request->check_categories);
        }

        if (!empty($request->price_range) && count($request->price_range) > 0) {
            $filter_old_price = array_merge($filter_old_price, $request->price_range);
        }

        //filter sorting begin
        if (!empty($request->orderby)) {
            if ($request->orderby == "lowtohigh") {
                $filter_sorting = "lowtohigh";
            }
            if ($request->orderby == "hightolow") {
                $filter_sorting = "hightolow";
            }
        }
        //filter sorting end
        
        $products1 = DB::table('products')->select('id')->whereIn('parent_id', $product_category)->where(['status' => 1, 'flag' => 0])->where('ecom','ONLINE');


        if (count($filter_brands) > 0) {
            $products = $products1->whereIn('brand_id', $filter_brands);
        }
        $products1 = $products1->get()->toArray();

        $products = DB::table('products')->select('id')->whereIn('id', array_column($products1, 'id'))->where('ecom','ONLINE');

        if (!empty($request->min_price_filter) && !empty($request->max_price_filter)) {
            $products = $products->whereBetween('sale_price', array(floatval($request->min_price_filter), floatval($request->max_price_filter)));
        }
        if (!empty($request->orderby) && $request->orderby == "lowtohigh") {
            $products = $products->orderBy('sale_price', 'ASC');
        }
        if (!empty($request->orderby) && $request->orderby == "hightolow") {
            $products = $products->orderBy('sale_price', 'DESC');
        }

        $products = $products->get()->toArray();

        $products = DB::table('products')->whereIn('id', array_column($products, 'id'))->where('ecom','ONLINE');
        if (!empty($request->min_price_filter) && !empty($request->max_price_filter)) {
            $products = $products->whereBetween('sale_price', array(floatval($request->min_price_filter), floatval($request->max_price_filter)));
        }
        if (!empty($request->orderby) && $request->orderby == "lowtohigh") {
            $products = $products->orderBy('sale_price', 'ASC');
        }
        if (!empty($request->orderby) && $request->orderby == "hightolow") {
            $products = $products->orderBy('sale_price', 'DESC');
        }
        $products = $products->paginate(12);

        $product_details = array();
        $product_medias = array();
        foreach ($products as $pro) {
            array_push($product_details, Product::where('id', $pro->id)->first());
            array_push($product_medias, ProductMedia::where('product_id', $pro->id)->where(['flag' => 0, 'media_type' => 'image'])->orderBy('sequence','asc')->first());
        }
        $product_details = collect($product_details);
        $product_medias = collect($product_medias);
        $last_page = $products->lastPage();
        $current_page = $products->currentPage();
        $no_of_pages = array();
        for($i = $current_page; $i <= $current_page+3; $i++){
            if($i <= $last_page){
                array_push($no_of_pages, $i);
            }
        }

        $prev = 'true';
        if($products->currentPage() == 1){
            $prev = 'false';
        }

        $next = 'true';
        if($products->lastPage() == $products->currentPage()){
            $next = 'false';
        }

        return view('frontend.product.category', compact('main_category', 'slug', 'sub_categories', 'categories', 'brands', 'products', 'product_medias', 'product_details', 'filter_old', 'filter_old_price', 'max_price_filter', 'min_price_filter', 'filter_sorting', 'filter_brands', 'min_price_old', 'max_price_old','no_of_pages','next','prev'));
    }

    static function findParent($id)
    {
        $cat = Category::where('id', $id)->first();
        if ($cat->parent_id != null) {
            $p = self::findParent($cat->parent_id);
            return $p;
        } else {
            return $cat->id;
        }
    }

    //for shop page
    public function shop(Request $request, $tag)
    {
        if($tag == 'all'){
            $tag = NULL;
        }
        $from = 0;
        $to = 10;
        $total_counts = 0;
        $sub_categories = Category::where(['parent_id' => null, 'status' => 1, 'flag' => 0])->with('subcategory.subcategory')->get();
        $brands = Brand::select('id', 'name')->where(['status' => 1, 'flag' =>  0])->get();
        $product_category = array();
        $min_price_filter = 0;
        $max_price_filter = DB::table('products')->where('tags', 'like', '%' . $tag . '%')->where('ecom','ONLINE')->max('sale_price') + 100;
        $min_price_old = 0;
        $max_price_old = 0;
        if (isset($request->min_price_filter) && !empty($request->min_price_filter)) {
            $min_price_old = floatval($request->min_price_filter);
        }
        if (isset($request->max_price_filter) && !empty($request->max_price_filter)) {
            $max_price_old = floatval($request->max_price_filter);
        }

        if (!empty($request->from) || !empty($request->to)) {
            $from = intval($request->from);
            $to = intval($request->to);
        }

        //fiter function begin
        $filter_old = array();
        $filter_old_price = array();
        $filter_sorting = "";
        $filter_brands = array();

        //brands filter begin 
        if (!empty($request->filter_brand) && count($request->filter_brand) > 0) {
            $filter_brands = array_merge($filter_brands, $request->filter_brand);
        }
        //brands filter end

        if (!empty($request->filter_category) && count($request->filter_category) > 0) {
            $check_categories = Category::select('id')->whereIn('slug', $request->filter_category)->get()->toArray();
            $check_categories = array_column($check_categories, 'id');
            $request->check_categories = $check_categories;
            $filter_old = $request->filter_category;
        }

        //filter function end
        if (!empty($request->filter_category) && count($request->filter_category) > 0) {
            $product_category = array_merge($product_category, $request->check_categories);
        }

        if (!empty($request->price_range) && count($request->price_range) > 0) {
            $filter_old_price = array_merge($filter_old_price, $request->price_range);
        }

        //filter sorting begin
        if (!empty($request->orderby)) {
            if ($request->orderby == "lowtohigh") {
                $filter_sorting = "lowtohigh";
            }
            if ($request->orderby == "hightolow") {
                $filter_sorting = "hightolow";
            }
        }
        //filter sorting end

        $products1 = DB::table('products')->select('id')->where(['status' => 1, 'flag' => 0])->where('tags', 'like', '%' . $tag . '%')->where('ecom','ONLINE');
        if (!empty($filter_brands) && count($filter_brands) > 0) {
            $products1 = $products1->whereIn('brand_id', $filter_brands);
        }

        if (count($product_category) > 0) {
            $products1 = $products1->whereIn('parent_id', $product_category);
        }
        $products1 = $products1->get()->toArray();

        $products = DB::table('products')->where('tags', 'like', '%' . $tag . '%')->whereIn('id', array_column($products1, 'id'))->where('ecom','ONLINE');

        if (!empty($request->min_price_filter) && !empty($request->max_price_filter) && $request->max_price_filter > floatval(0)) {
            $products = $products->whereBetween('sale_price', array(floatval($request->min_price_filter), floatval($request->max_price_filter)));
        }
        if (!empty($request->orderby) && $request->orderby == "lowtohigh") {
            $products = $products->orderBy('sale_price', 'ASC');
        }
        if (!empty($request->orderby) && $request->orderby == "hightolow") {
            $products = $products->orderBy('sale_price', 'DESC');
        }
        $products = $products->paginate(12);
        // $total_counts = count($products);
        // if ($to > $total_counts) {
        //     $from = $request->to - 10;
        //     $to = $request->to;
        // }

        // $products = array_slice($products, $from, 10);

        $product_details = array();
        $product_medias = array();
        foreach ($products as $pro) {
            array_push($product_details, Product::where('id', $pro->id)->first());
            array_push($product_medias, ProductMedia::where('product_id', $pro->id)->where(['flag' => 0, 'media_type' => 'image'])->orderBy('sequence','asc')->first());
        }
        $product_details = collect($product_details);
        $product_medias = collect($product_medias);

        $last_page = $products->lastPage();
        $current_page = $products->currentPage();
        $no_of_pages = array();
        for($i = $current_page; $i <= $current_page+3; $i++){
            if($i <= $last_page){
                array_push($no_of_pages, $i);
            }
        }

        $prev = 'true';
        if($products->currentPage() == 1){
            $prev = 'false';
        }

        $next = 'true';
        if($products->lastPage() == $products->currentPage()){
            $next = 'false';
        }
        if($tag == Null){
            $tag = 'all';
        }

        return view('frontend.product.shop', compact('sub_categories', 'brands', 'products', 'product_medias', 'product_details', 'filter_old', 'filter_old_price', 'max_price_filter', 'min_price_filter', 'filter_sorting', 'filter_brands', 'min_price_old', 'max_price_old', 'total_counts', 'from', 'to','no_of_pages','prev','next','tag'));
    }
}
